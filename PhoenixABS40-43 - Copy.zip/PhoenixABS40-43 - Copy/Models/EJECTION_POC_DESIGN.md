# Phoenix ABS 40‑43 — servo‑released spring ejection, POC **v1 (sliding catch)**

Design logic and build record for `PhoenixABS40-43_ejection_poc_v1.py` and its outputs.
This document stands alone; it deliberately does **not** depend on the vehicle‑level
`DESIGN.md` (which is out of date on this subsystem).

Frame throughout: **Z along the tube axis, +Z toward the nose, Z = 0 at the anchor
bulkhead's forward face.** Airframe ⌀43 OD / ⌀40 ID.

---

## 0. Status at a glance

| Item | State |
|---|---|
| Mechanism architecture | ✅ **Fixed — sliding catch on a bonded collar, crank‑driven, dead‑centre held.** Replaces the scrapped v0 annular‑cam attempt (§3.3). |
| Fits the ⌀40 bore | ✅ Verified over the full knob sweep — worst moving radius 19.2 mm vs the 19.5 mm limit. |
| Threaded rod | ✅ **Eliminated.** No metal spine — the shaft is a printed ⌀6 part (a ⌀6 CF rod is an optional drop‑in, §10.2). |
| Shaft robustness | ⏳ **Split 2026‑09‑08 (d).** The ⌀5.4 locating groove is **deleted** — the shaft is genuinely ⌀6 solid end to end. `PistonShaft` is now two parts, **`PistonHead` + `Shaft`**, joined by a blind ⌀6 socket in the hub and solvent‑welded, so the shaft prints **axially** (layers along its length): side‑load to break at the socket mouth **~8 N** in‑plane vs ~4 N shaft‑up. Better, not robust — a ⌀6 pultruded CF rod in the same socket (~284 N) is the real fix (§10.2). Report **[5b]** prints the number every run. |
| Catch load direction | ✅ **FIXED (Option B, §6.14).** Catch is a bonded CatchCollar whose top face reacts +Z into a full‑diameter plate; free rise 0.025 mm, bounded by a positive cocking stop at **1.0 mm** (§6.14 — raised from 0.6 for slider‑droop margin). Report **[5b] PASSES**. |
| Assemblability | ✅ **Geometry verified; re‑run 2026‑09‑08 (d).** Every moving/removable fit derives from the `CL_*` block and passes report **[F]**; the new **[T]** section checks thin features *within* each part (the class that dropped the collar rib). Re‑slice from `Print Files/Ejection System/`. |
| All fasteners printable | ✅ Crank pin (⌀3) and RBF pin (⌀2) are printed parts. Only non‑printed items: the spring, 3× M3 screws. |
| Spring rate / `F_max` | ❌ **UNMEASURED.** Whole design is checked against `F_MAX_ASSUMED = 34 N`; nothing is *gated* by it (§10). |
| Servo | ⏸ v1 is a **manual knob**. Servo mounts later on the knob's D‑flat (§10). |
| Simulation / flight clearance | ❌ Not done. This is a bench POC. |
| Parts | 9 printed (`Cage`, `BulkheadDisc`, `PistonHead`, `Shaft`, `Slider`, **`CatchCollar`** × 2 identical halves, `Knob`, `TubeStub`, `DummyNose`) + printed pins. **All checks PASS** except: **[T]** flags the collar's D‑flat wall at 0.05 mm (prints as a C — **accepted, unfixable in this layout**, §6.14) and warns "thin" on the disc rim at the peg holes (§10.12); **[5b]** flags the shaft as WEAK in handling (§10.2). |
| Source of truth | ✅ **`PhoenixABS40-43_ejection_poc_v1.py`.** Revisions (b)/(c)/(d) were prototyped then fully back‑ported; the script was re‑run and regenerated every output (STEP → `Models/`, STL → `Print Files/Ejection System/…`). Edit the script, re‑run, never edit the STL/STEP/FCStd. |

---

## 1. Scope

A **proof of concept of the release event only**: cock the real spring, hold it against
structure, and let go on command — by hand now, by a 9 g servo later. It is
**airframe‑representative** (drops into the ⌀40 bore, screws to the wall) so the same
parts migrate toward the flight bay, but it is **not** a flight article: no motor
interface, no recovery harness, no qualification.

Given: a compression spring, **free ≈ 85 mm, cocked ≈ 45 mm, ⌀10 mm OD**, working
stroke **40 mm**, wire gauge and rate unknown.

---

## 2. The brief this is built against

1. **Servo‑released spring is the sole deployment event.** The release must be
   mechanical and reusable — no pyro, no shear pins.
2. **Everything fits inside the ⌀40 mm airframe bore** — spring, piston, latch, knob,
   and the future servo.
3. **The cocked load is held by geometry, not by servo/knob torque.** A servo with no
   signal goes limp; a brownout on the pad must not deploy the rocket.
4. **Fully 3D‑printable** (ABS), minimum bought hardware.
5. **No threaded rod** as a structural spine (explicit user constraint).
6. The spring **will buckle unguided** at L/D 8.5 and ~47 % compression — it needs a
   guide.
7. `F_max` is unknown until measured, so the design must be **robust across 7–53 N**
   (the plausible range for ⌀10 × 85/45 wire gauges) and re‑validate by re‑running,
   not by redesign.

---

## 3. Design logic — why a sliding catch

### 3.1 What the release has to do

Hold a piston down against ~34 N (assumed) of cocked spring, react that load into the
airframe, and on command move something a few millimetres so the piston is free —
without the actuator ever carrying the spring load, and inside a ⌀40 tube that already
has a ⌀10 spring and a piston up its middle.

### 3.2 Why "the servo just slides a pin out" is hard here

The intuitive latch — a cross‑pin through the shaft, in brackets, that the servo pulls
sideways — runs into the bore. To fully withdraw a pin from a collar/shaft on the tube
axis you need ~10–15 mm of travel; a servo crank or an offset cam that fits beside the
⌀10 spine in a ⌀40 tube tops out near 6–7 mm. Every "actuator offset from the axis"
layout fights the wall.

### 3.3 Rejected — v0: annular cam + straight‑offset slots

The first attempt put a rotating annular cam on the tube axis with two **straight
offset slots** (`x_follower = x0 / cos θ`), driving two opposed ⌀3 latch pins ~2.4 mm
each. It *worked* and it *fit* and it had a clean dead‑centre at ARMED — but:

- **2.4 mm of pin travel is illegible.** You cannot see it move, so you cannot trust
  it or explain it.
- Two opposed pins + L‑shaped follower tongues + a journalled cam plate is a lot of
  cramped, thin, support‑hungry printed geometry for what is meant to be a POC.
- Margins ran to 0.2–0.5 mm in several places.

It was scrapped. Lesson kept: **legibility is a design requirement for a POC** — if
the person building it can't watch it work, the design is wrong for the job.

### 3.4 Rejected — over‑centre servo linkage on a cross pin

A four‑bar over‑centre linkage that makes the spring load produce zero torque about the
servo shaft. Meets requirement 3, but: it is geometry you have to get exactly right,
verify by test, and it still needs the pin to travel far enough to clear the shaft
(§3.2). More failure modes than the alternative, not fewer.

### 3.5 Chosen — catch face + sliding fork + crank

> The original form of this used a **groove shoulder** turned into the shaft. That was
> replaced by a **bonded CatchCollar** (§6.14, rev (c)) and the shaft split into
> `PistonHead` + `Shaft` (§6.15, rev (d)). The kinematics below are unchanged; read
> "collar top face" for "shoulder".

- The **Shaft** carries a bonded **CatchCollar** near its lower end. The collar's **top
  face** is an **upward‑facing** catch surface.
- A flat printed **Slider** in a channel across the cage has a **U‑notch** whose rim
  bears **down** on that top face. Cocked spring load: shaft → collar bond → collar top
  → slider → a full‑diameter **reaction plate** fused to the cage legs → 3 M3 screws →
  airframe. **The knob carries none of it** — the load is axial (Z), the slider moves
  radially (X), the two are orthogonal. (The fixed **ledge** below the slider hosts the
  knob journal, carries the slider, and its stepped bore is the positive cocking stop.)
- The **Knob** has an off‑centre **crank pin** riding a cross‑slot in the slider
  (a scotch‑yoke). Turn the knob 180° and the crank pin swings the slider **6 mm**
  clear of the collar → spring fires.
- **ARMED (θ = 0°) and FIRED (θ = 180°) are both crank dead centres** (`dX/dθ = 0`).
  A shove on the slider produces zero knob torque at either end. The hold is geometric.
  **There is no detent** (§10.19) — between ARM and FIRE only slider friction holds it;
  at ARMED the dead centre plus the RBF pin through the knob are the hold.

Travel needed to release = notch radius + shaft radius ≈ 1.8 + 3 = 4.8 mm; provided
6 mm (crank radius 3, sweep 180°). This is the smallest, most readable mechanism that
meets all seven brief points in a ⌀40 tube.

---

## 4. How it works

```
   PISTON HEAD  ────────────█████████████  ⌀38, on the 45 mm spring; d6 socket in the hub
                                 │  ⌀6 SHAFT, solvent-welded into the head socket (6.15)
   bulkhead disc  ══════╤════════│════════╤══════   ⌀39.5, slides on the shaft,
    (slides on,  ════════╡═══[ spring ]═══╡═════    locates on the cage-leg pegs
     screws retain)      │                │        (light push), 3× M3 screws hold
        cage legs  ║      │                │      ║
                   ║      │                │      ║   ⌀6 shaft, SOLID end to end -- no groove (6.14/d)
    REACTION PLATE ╬══════╪════════════════╪══════╬   <- THIS takes the +Z load
          (fixed)  ║      │                │      ║      (v1 reacted into a 2 mm bridged lip)
        SLIDER ────╫ ████████████████████████████ ╫   rim bears DOWN on the collar top
   CatchCOLLAR ────╫    ▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓    ╫   ⌀9, bonded, TWO IDENTICAL HALVES
        LEDGE  ════╬══════╪════════════════╪══════╬   1.0 mm under the collar this bore
          (shelf)  ║      │                │      ║   steps to ⌀6.8 = POSITIVE COCKING
        carrier ═══╬══════╪════════════════╪══════╬   STOP, so free rise is BOUNDED
                   ●──crank pin (⌀3) ── in the slider's cross-slot
        KNOB  ────╮╰──────┤ off-axis at X = -8, radius 3 ─── D-flat (servo later)
             grip ╯  ⌀5.5 spigot = the lateral bearing (clear of the crank pin)
                     RBF pin ⊗ at r 15 from the axis -- SOLID carrier (10.16)
```

**ARM → FIRE:** knob 0 → 180°. Crank pin world‑X goes −5 → −11; the slider,
constrained to X by its rails, follows: `dX = 3·(cos θ − 1)`, 0 → −6 mm. The notch
(which opens toward +X) slides off the **collar**; the spring drives the
piston + shaft + nose up. The stroke self‑limits when the spring reaches free length
(§6.2). ARMED is re‑established by pressing the piston back down ~40 mm and turning the
knob to ARM.

---

## 5. Parts and the numbers that define them

| Part | Defining geometry | Why |
|---|---|---|
| **PistonHead** | ⌀38 × 8 piston disc; ⌀13 × 4 hub; ⌀11.5 × 2.5 spring‑seat counterbore; a **blind ⌀6.1 socket** bored 10 mm up into the hub for the Shaft, 0.3×45 mouth chamfer (peak ⌀6.7 clears the assumed spring ID 7.2); ⌀1.6 cross‑hole in the hub cap (bench tether) | split off the shaft (§6.15) so it prints **flat**, disc down — no ⌀38 overhang, no tall tower |
| **Shaft** | **⌀6 SOLID rod**, Z −63 → 52.5, 45° lead‑in at the stub end; top 10 mm solvent‑welded into the PistonHead hub socket; **no groove, no neck, no reduced section** | ⌀6 < assumed spring ID (7.2) so the shaft **is** the buckling guide; solid ⌀6 so it threads the ⌀6.8 bulkhead bore (§6.2); prints **axially** (§6.15) — bending in‑plane ~40 MPa vs ~20 interlayer; a ⌀6 CF rod is a drop‑in (§10.2) |
| **Cage** | 4 legs at ⌀35.2, tops at Z −8 with **⌀3 pegs** (1.2 mm lead cone); fixed **ledge** Z −56…−60 with the slider channel (rails + lip, pocket = slider + `CL_SLIDE`); knob **journal** ⌀8.4 at (−8, 0); carrier Z −60…−65; 3 radial M3 holes at the ledge | ledge is the load reaction; journal sets the crank axis clear of the ⌀6 shaft; pegs locate, screws retain (§6.4) |
| **BulkheadDisc** | ⌀39.5 × 8; ⌀6.8 shaft bore; ⌀11.5 spring‑seat counterbore; 4× ⌀3.2 blind peg holes, 5.5 deep (0.55 mm wall to the OD — a watch item, §10.12); 3 radial M3 holes | separate from the cage so it can **slide onto the shaft over the spring** (§6.3); ⌀3.2 vs ⌀3 peg = 0.2 mm dia clearance, a **locating** fit — the M3 screws retain |
| **CatchCollar** | ⌀9 × **2.0**, D‑flat at x −3.1, ⌀6.1 bore, **no rib** (rev (d) — the 0.25 mm rib was sub‑nozzle, [T]); **printed as two identical halves split at y = 0** | the catch (§6.14). Its top face is the upward‑facing surface the slider bears on, so the spring load never crosses a reduced section. D‑flat clears the crank‑pin sweep — but it sits only 0.05 mm outside the bore, so the collar **prints as a C, not a D**: bearing is unaffected, bond area is ~15 % less than a full ring ([5] computes the real arc). Halves let a ⌀9 collar go onto a shaft that must thread a ⌀6.8 bore |
| **Slider** | ~13 × 12.3 × 4 bar (**nominal — all fit slop is in the cage pocket**); **⌀6.8** U‑notch opening +X; crank cross‑slot ±1.9 in X (drive), −1.5…+6.5 in Y (idle); thumb tab out the access slot | notch now only has to clear the **unbroken ⌀6 shaft** (+0.40 radial, `CL_BORE`); its rim bears on the CatchCollar’s top face (11.69 mm², 2.9 MPa); slot long in Y absorbs the crank pin's Y swing |
| **Knob** | ⌀20 grip offset to axis (−8, 0); ⌀7.6 journal shaft (0.4 radial in the ⌀8.4 journal); crank‑pin bore ⌀3.4 at radius 3; D‑flat; ⌀2.5 RBF hole | offset −8 keeps grip + travel inside R 19.5; radius 3 → 6 mm slider travel over 180°; bore +0.2 for a **printed** pin |
| **TubeStub** | ⌀43/⌀40 × ~165; longitudinal viewing window (+Y); access slot (+X) over the latch/knob; 6 radial M3 holes | airframe stand‑in; window to watch it work; slot to insert the slider, RBF, and turn the knob |
| **DummyNose** | ⌀39.0 × 25 hollow plug, 2 friction bands (⌀39.0 on a ⌀37.4 shoulder — 0.8 mm proud so they print as **distinct** bands; was ⌀38.8, 0.1 mm proud → sub‑nozzle, [T]), ⌀8 axial hole | the visible "it fired" object; slides free — bands are light drag, not a press; the axial hole is a poke‑through for cocking |
| *pins* | printed ⌀3 crank pin + ⌀2 RBF pin, both with a small head + lead chamfer (`ejection_poc_test_pins.py`) | requirement 4 — nothing metal but the spring and screws |

---

## 6. Decisions and rationale

### 6.1 Integral printed shaft, no threaded rod
The rod was carrying three jobs — spring guide, tension member, cocking screw — and it
was an imposed part the brief rules out (requirement 5). Folding the shaft into the
piston removes the rod, the nuts, and the DrawCollar. The shaft sees ~34 N in
**compression**‑then‑tension along its length: ~1 MPa, trivial even inter‑layer.

### 6.2 ⌀6 the whole way — no ⌀11 stop flange
An earlier version put a ⌀11 flange mid‑shaft as a positive 40 mm stop. It made the
part **unassemblable**: the flange cannot pass the ⌀6.8 bulkhead bore, from either end.
Removed. The shaft is now ⌀6 from the piston to the groove, so it threads straight
through. **Stroke limiting** is now: (a) the spring reaching free length — gentle,
self‑limiting; (b) for the first bench fires, a short tether from the hub cross‑hole
to a cage leg. A positive stop is a flight‑article item (§10).

### 6.3 Two‑piece bulkhead: `Cage` + slide‑on `BulkheadDisc`
Because the piston/shaft is one rigid part with a ⌀38 disc on one end, the spring and a
one‑piece bulkhead could never get onto the shaft. Splitting the disc off lets the
assembly be: spring on from the stub end → disc on from the stub end → the whole stack
drops into the cage from the top. Verified: nothing on the shaft below Z −8 exceeds the
⌀6.8 bore.

### 6.4 Legs peg into the disc (not glued)
User request, "for the time being." Each leg top has a ⌀3 peg with a 1.2 mm lead cone;
the disc has ⌀3.2 blind holes → **0.2 mm diametral clearance, a locating fit** — a light
hand push, and it comes apart by hand. The lead‑in is the cone on the peg (a funnel in
the disc hole would break through the thin disc rim at that radius, §10.12). The 3
radial M3 tube screws are the retention; the pegs only clock the disc and hold it
during handling.

This was **⌀2.9 in / ⌀3 peg = 0.1 mm interference** in v1‑as‑first‑printed, described as
a "press/click." On an FDM printer a ⌀3 hole comes out ~0.2–0.4 mm undersize and a ⌀3
post ~0.1–0.2 mm oversize, so that nominal 0.1 mm interference prints as a 0.3–0.5 mm
jam — the disc will not seat, or it splits the thin web around the hole. It also never
"clicked": a straight cylinder in a blind hole is a press, not a snap. **A real click
needs a barbed peg into a through‑hole with a relief groove, or cantilever snap
fingers** — a redesign, deferred; the locating fit + screws is the right default here
(§6.11, §10.7).

### 6.11 FDM fit clearances are a named block, checked by report section [F]
Every moving or removable interface is now derived from one of six constants
(`CL_SLIDE`, `CL_ROT`, `CL_BORE`, `CL_PIN`, `CL_PEG`, `CL_TUBE`) at the top of the
script, sized for ABS on a 0.4 mm nozzle. The slider channel is the worst v1 offender:
the rails sat on `SLIDER_YW_LO/HI` and the lip on `SLIDER_Z1` — **exactly** the slider
faces, a 0.00 mm sliding fit on three surfaces. It is now `slider nominal + CL_SLIDE`,
with **all the slop in the fixed cage pocket** so the ledge top (the load reaction
face) and the notch‑under‑shoulder engagement do not move. `CL_SLIDE = 0.5` (not 0.4):
the cage lip is a downward‑facing bridge over the channel (0.2–0.3 mm print sag) and
the slider base carries elephant's foot.

Why v1 passed every check and still jammed: sections [4], [5] and [7] measure fits with
`Shape.common().Volume`, which reads **0 mm³ for a 0.00 mm gap and for a 0.50 mm gap
alike** — a boolean can only see *interference*, never *insufficient clearance*. Report
section **[F]** now checks each fit gap by arithmetic on the constants and flags the
thinnest one; it is the check that would have caught this before the first print, and
the one that protects the next `STROKE` edit.

### 6.12 The ⌀2.8 groove neck was the brittle part — ⌀4.0 filleted *(superseded by §6.14)*
> **Superseded.** This widened the neck; §6.14 removed it altogether. Kept for the
> reasoning and the numbers — they are what sized the collar.

The shaft printed brittle, and the reason was not the ~105 mm ⌀6 tower (§10.2) but the
groove that interrupts it. Section modulus `Z = πd³/32`:

| Section | Z | M_fail @ 20 MPa interlayer | Side force at the piston to break it |
|---|---|---|---|
| ⌀6 shaft | 21.2 mm³ | 424 N·mm | ~4.5 N |
| ⌀2.8 neck (**was**) | 2.15 mm³ | 43 N·mm | **~0.4 N** |
| ⌀4.0 neck (**now**) | 6.28 mm³ | 126 N·mm | ~1.1 N |

Lever arm neck→piston ≈ 112 mm, so 0.4 N is 40 g of sideways nudge — the piston head
alone (~10 g) spends a quarter of the old neck's capacity just being held horizontally.
Printed shaft‑up, every layer boundary is normal to the bending axis, so this is raw
interlayer adhesion; and a ⌀2.8 circle at a 0.4 mm nozzle slices as ~3 touching
perimeter loops with no infill — a column of Z‑seam start/stop defects running the
length of the neck, which is exactly where the crack starts.

**Changed:** `GROOVE_R` 1.4 → **2.0**, `NOTCH_R` 1.8 → **2.6** to follow it, R0.3 fillets
at both groove roots (sharp step Kt ≈ 2.8 → ≈ 2.0), and an R0.3 fillet where the shaft
meets the counterbore floor — the other sharp root, and the one at maximum bending
moment when the part is handled by the piston.

Net: **×2.9 on neck bending, ×2.0 on neck tension area, ×~1.4 on the stress
concentration.** Combined with a flat print (below) it is ~8× the original.

**What bounded each number** (all re‑verified in FreeCAD, see the run log):

| Constant | Was | Now | What stopped it going further |
|---|---|---|---|
| `GROOVE_R` | 1.4 | 2.0 | catch land `SHAFT_R − GROOVE_R` = 1.0 mm; bearing 7.9 MPa vs 40 |
| `NOTCH_R` | 1.8 | 2.6 | slider −Y web `\|SLIDER_YW_LO\| − NOTCH_R` = 1.4 mm; and `SLIDER_TRAVEL` ≥ `NOTCH_R + SHAFT_R` = 5.6, provided 6.0 |
| groove fillet | — | R0.3 | fillet peak ⌀4.6 needs a **running** 0.30 gap inside the ⌀5.2 notch — both fillets are in the slider's path (upper on insertion at ARMED, lower on retraction at FIRE), so this is a sliding fit, not a static one (§6.11) |
| root fillet | — | R0.3 | peak ⌀6.6 must stay inside the assumed spring ID 7.2 (§10.1) |
| `SHAFT_R` | 3.0 | 3.0 | **not raised** — only ×1.46, and it spends margin against an *unmeasured* spring ID |

⚠ **Do not buy notch clearance with `SLIDER_TRAVEL`.** Swept `R_max` is 19.235 against
the 19.5 limit, and that number is the slider's thumb tab at FIRED; travel moves it 1:1,
so +0.3 mm fails containment [0]. Shorten the tab instead.

**Print orientation.** *(rev (d): the "split the part" option below is now built —
§6.15.)* The single `PistonShaft` is gone. `Shaft` prints **axially** by default
(`Ready to Print/`): perimeters run **along** the shaft, so bending loads in‑plane ABS
(~40 MPa) not interlayer (~20), ~×2. The cost that hasn't gone away: **0.2–0.4 mm of
sag/elephant‑foot** on a shaft that has only 0.4 mm of ⌀6.8‑bore clearance — **sand the
shaft round** before assembly, or drop in a ⌀6 CF rod (§10.2) and skip the problem.
`PistonHead` prints flat, disc down; its ⌀38 disc sits on the bed with no tower and no
overhang, though the down‑facing ⌀11.5 spring pocket wants a bridge or a little support.

### 6.13 The catch cannot simply be flipped — a groove loads the neck by construction
Confirmed 2026‑09‑06: **the shaft snapped while being cocked.** That is the lip collision
(§10.14) — the ⌀6 shaft cannot reach the cocked position because the retaining lip is
solid across its path, and forcing it loads the neck's upper root sideways. That defect
is fixed. But diagnosing it exposed the deeper problem.

The spring drives the shaft **+Z**, so the catch must present an **upward‑facing** face on
the shaft for the slider to press down on. On a turned groove the only upward‑facing face
is the groove's *lower* root. And the force has to get from the piston, down the ⌀6
shaft, across the groove, to that lower root — **through the neck, in tension**.

So a groove‑and‑fork catch that resists +Z pulls the neck in tension *by construction*.
**Reversing the reaction face is necessary but not sufficient.** Report [5b] now measures
this directly (free +Z travel before the catch bites: **2.05 mm**) and fails.

**Option A — short‑lost‑motion groove + a real reaction plate.** Slider underside bears on
the groove's lower root; groove height becomes slider thickness + ~0.5 mm instead of
6 mm, so free rise drops 2.05 → ~0.5 mm. Replace the 2 mm bridged `lip` with a
full‑diameter plate fused to the legs, ⌀6.8 bore. The neck stays in the load path
(2.71 MPa nominal × Kt 2.0 = 5.4 MPa static vs ~20 interlayer) but the impact factor
drops with the drop height. *Cost:* cocking gets fussy — you must press to within
~0.5 mm for the slider to enter. A lead chamfer on the notch rim helps.

**Option B — a separate catch collar, and no neck at all. ← recommended.** The shaft stays
**⌀6 unbroken** from the piston to the stub end; a shallow ⌀5.4 × 0.5 locating step
replaces the groove (a 0.3 mm shoulder, `Z` = 15.5 mm³ — still 2.5× the ⌀4.0 neck). A
printed collar (⌀9 × 8, slotted so it goes on sideways) drops onto the step *after* the
bulkhead disc is on and is solvent‑welded. Its top face is the upward‑facing catch face;
the slider bears on that, reacted by the plate above.

| | Now | Option A | Option B |
|---|---|---|---|
| weakest section | ⌀4.0 neck | ⌀4.0 neck | **⌀6.0 shaft** |
| side‑load to break | 1.12 N | 1.12 N | **3.79 N** |
| neck tension at 34 N | 2.71 MPa | 2.71 MPa | **none — not in the path** |
| free rise / impact | 2.05 mm | ~0.5 mm | ~0.5 mm |
| extra parts | — | — | 1 printed collar |

Option B's bond carries the full 34 N in shear over π·6·8 = 151 mm² → **0.22 MPa**, which
is nothing for an acetone‑welded ABS joint. It costs one printed part and keeps the
brief's "no bought hardware" (requirement 4). **Not yet built — needs your call.**

### 6.14 Option B built: the groove is gone, the catch is a bonded collar
§6.13 costed two fixes; **B is built.** The shaft is **⌀6 solid** end to end.

> **Rev (d) update.** (c) left a ⌀5.4 × 0.8 locating groove "that the collar encases",
> keyed by a rib inside the collar bore. That rib was **0.25 mm thick radially** — under
> one nozzle width, so it never printed (report **[T]** flags this class now). With the
> rib gone the groove located nothing and backstopped nothing while costing ~27 % of the
> local section and two R0.2 raisers, so **both the groove and the rib are deleted**. The
> collar now locates at glue‑up by sitting flush to the slider underside, and the **bond
> is the whole load path** — which the paragraphs below already say it is. The shaft is
> genuinely unbroken; report [9] verifies the true minimum section is ⌀6.0.

**How it works.** A **CatchCollar** (⌀9, 2.0 mm, D‑flatted on −X) is solvent‑welded to
the shaft. Its **top face** is the upward‑facing surface the slider bears down on, and
the slider is reacted by a **full‑diameter plate** fused to the legs — replacing the
2 mm bridged `lip` that v1 was reacting into. Load path: shaft → collar bond → collar
top → slider → reaction plate → legs → screws → airframe.

| | v1 groove | §6.12 ⌀4 groove | **§6.14/d collar** |
|---|---|---|---|
| weakest section in the path | ⌀2.8 neck | ⌀4.0 neck | **⌀6.0 shaft (solid)** |
| side‑load to break it | 0.38 N | 1.12 N | **~4 N shaft‑up / ~8 N axial** (§6.15, [5b]) |
| tension at 34 N | 5.52 MPa × Kt 2.8 | 2.71 × Kt 2.0 | **1.20 MPa, no Kt** |
| free rise before the catch bites | 2.05 mm | 2.05 mm | **0.025 mm** |
| worst‑case impact | 50 MPa (fails) | ~25 MPa (marginal) | **11.3 MPa vs ~20** |
| bearing | 4.33 mm² / 7.9 MPa | 4.33 / 7.9 | **11.69 mm² / 2.9 MPa** |

**Two identical halves.** The collar splits at y = 0 — the D‑flat is symmetric in y, so
both halves are the *same* part, not mirrored (report [9] asserts this). They clamp on
through the access slot at any point in the assembly, which is what makes a ⌀9 collar
fittable at all on a shaft that has to thread a ⌀6.8 bulkhead bore.

**The bond is the whole load path.** Report [5] computes it from the *printable*
interface, not `2·π·r·h`: the D‑flat wall goes sub‑nozzle for |y| < ~1.4 mm, so ~55° of
the bore prints open — **~32 mm² of shaft arc** (85 % of a full ring) **+ ~3 mm² on the
+X split face** (the −X split face is the open side of the C) = ~35 mm² → **0.98 MPa**
shear at 34 N, ~10× margin on solvent‑welded ABS. No groove, no backstop: cure the joint
before cocking (§8).

**A positive cocking stop, so free rise is a design number.** The ledge bore steps down
to ⌀6.8 at Z −59.0, **1.0 mm** below the collar's underside (21.6 mm² of contact,
1.6 MPa). Press to cock and the collar bottoms on that shelf; release and it rises 1.0 mm
at most. Previously the lost motion was whatever the operator overpressed — unbounded,
and it was landing on a thin neck.

**Why 1.0 mm and not 0.6.** The ledge's centre is *necessarily* void — the collar has to
pass through it at fire, and so does the crank‑pin sweep — so the slider seats on only
**59.5 of 184.5 mm²**, with its support centroid at Y +4.2 against a slider centre of
+1.35. Inward rail flanges do **not** fix this: the ledge already fills everywhere a
flange could go, and the void is central. So the slider droops when unloaded, pivoting
about that support until its far top corner meets the reaction plate `CL_SLIDE` above —
**0.62 mm at the notch end**. While arming, the collar is held down on the cocking stop,
so the gap has to exceed that droop or the slider catches on the collar's edge as it
slides in. At 0.6 mm it would have. At 1.0 mm there is 0.38 mm of margin, and the impact
cost is small because nothing in the load path is reduced any more: DAF 9.4 × 1.20 MPa =
**11.3 MPa against ~20**. Report [5] measures the seating, the droop and the stop.

**What bounded the collar.** ⌀9 is not arbitrary:

| Limit | Value | What sets it |
|---|---|---|
| max radius | 4.77 | nearest FIRED slider material (r 5.25 now, +0.75 margin) |
| D‑flat at x −3.1 | — | the ⌀3 crank pin's swept disc, r 4.5 about the knob axis, + `CL_ROT` |
| round collar impossible | r ≤ 3.8 | knob journal at x −8 — too little land over a 3.4 notch, hence the D |
| height 2.0 mm | — | 1.0 mm of cocking stop above the ledge shelf, which must beat the 0.62 mm slider droop |

The D‑flat costs only 1.2 mm² of bearing versus a full round.

### 6.15 The shaft is split: `PistonHead` + `Shaft`, socketed and solvent‑welded
**Done 2026‑09‑08 (d).** §6.12/§10.2 had long flagged that the ~105 mm ⌀6 shaft is the
weak part: printed **shaft‑up**, every layer boundary is normal to the bending axis, so
a side load at the piston of only **~4 N** breaks it — the piston head alone (~10 g)
spends a chunk of that just being held horizontal. Printing it **flat** loads in‑plane
ABS (~40 MPa) instead of interlayer (~20), roughly ×2, but a one‑piece part can't: the
⌀38 disc needs support and the shaft sags 0.2–0.4 mm — most of its 0.4 mm bore
clearance.

**The fix is to split the part.** `PistonHead` (disc + hub + spring‑seat counterbore)
prints flat, disc down. `Shaft` is a plain ⌀6 rod that prints **axially** (laid
horizontal, perimeters running along its length). They join at a **blind ⌀6.1 socket**
bored 10 mm up into the ⌀13 hub, solvent‑welded (`SHAFT_JOINT_DEPTH`).

| | one‑piece, shaft‑up | one‑piece, flat | **split (d)** |
|---|---|---|---|
| side‑load to break at the piston/socket | ~4 N | ~8 N | **~8 N** |
| ⌀38 disc | on the bed | needs support | **on the bed** |
| shaft roundness | true | sags 0.2–0.4 mm | **true** (printed alone) |
| parts | 1 | 1 | 2 + a glue joint |

- **Joint loads.** Cocked tension 34 N over the ⌀6 × 10 mm glue cylinder = **0.18 MPa**
  shear, ~50× margin. In bending (handling) the socket wall in the ⌀13 hub stiffens the
  section; the riser is the socket mouth, relieved by a 0.3×45 chamfer whose peak (⌀6.7)
  still clears the assumed spring ID 7.2 — the same constraint the old `FIL_ROOT` fillet
  carried (report **[F]** asserts it).
- **Still not "robust".** ~8 N is ×2, not unbreakable. Handle the shaft gently until
  glued into the head, then handle the assembly by the head. Report **[5b]** prints the
  side‑load‑to‑break number every run so it can't quietly go stale.
- **CF‑rod ready.** The socket is ⌀6, so a ⌀6 pultruded carbon rod (~284 N) is a
  drop‑in with no other change — the ABS shaft is the printable default, the CF rod the
  upgrade (§10.2).
- **Back‑to‑back test article.** The script also emits a **one‑piece** `PistonShaftOnePiece`
  STL (report section **[C]**) — the head and shaft fused, no socket, printed disc‑down /
  shaft‑up as a ~120 mm tower. Same envelope and same cage/disc/collar/spring interfaces
  as the split pair, so you can print both and break both. `[C]` prints its shaft‑up
  side‑load number (~4 N) next to the split's axial number (~8 N). It is **not** on the
  plate and **not** the recommended part.

### 6.5 Fully printed pins
Crank pin ⌀3, RBF pin ⌀2, both printed (`ejection_poc_test_pins.py`, 3 + 2 with
spares). The knob's crank bore is opened +0.2 mm for a printed pin's oversize; glue it
in. The crank pin is a ~6 mm cantilever carrying ~7 N at the worst angle → ~16 MPa
bending in printed ABS: marginal, so it is **replaceable** — reprint if it fails, or
drill it out and drop in a steel ⌀3 pin.

### 6.6 Scotch‑yoke crank, not a cam
A crank pin in a straight cross‑slot gives: a big readable motion (6 mm), a
closed‑form kinematic (`dX = r(cos θ − 1)`), and — the reason it beats an over‑centre
linkage — **two true dead centres** at the travel extremes, self‑holding regardless of
friction. Cost: 180° of knob rotation (fine by hand; §10 for the servo).

### 6.7 Offset knob at X = −8
On the tube axis the knob would collide with the ⌀6 shaft. Offset −8 (clear of the
shaft by ~1 mm) with a ⌀20 grip keeps the outermost point at R ≈ 18 through the whole
sweep, inside the 19.5 mm moving‑parts limit with margin.

### 6.8 Catch = a groove shoulder on a fork, **not** a shear pin
The load path is a printed rim bearing on a printed shoulder in **compression**
(~2 MPa), reacted by a fixed ledge directly under it — no bending in the fork tines,
no pin in shear, nothing that can "cam out" axially. Withdrawal is orthogonal to the
load, so it needs only to beat friction.

### 6.9 RBF pin locks the knob
A ⌀2 pin through aligned holes in the knob and the fixed carrier, at ARMED. It blocks
the **cam/knob**, independent of the slider, the crank, and anything electronic —
so a servo brownout with the RBF fitted still cannot deploy.

### 6.10 Recovery eyelet dropped
Removed from the disc "for now" at the user's request. A first‑fire tether loops
around a cage leg instead. The flight bulkhead needs a real anchor (U‑bolt / printed
eyelet) back.

---

## 7. Verification — what `PhoenixABS40-43_ejection_poc_v1.py` checks

Every run rebuilds all parts, heals them (STEP round‑trip + `removeSplitter`), and
writes `ejection_poc_build_report_v1.txt`. **All sections PASS as of the last run
(2026‑09‑08 (d))** except two deliberate flags: **[T]** on the collar's 0.05 mm D‑flat
wall (accepted, unfixable in this layout — §6.14) and a "thin" warn on the disc rim
(§10.12); and **[5b]** marks the shaft WEAK in handling (§10.2).

| § | Checks |
|---|---|
| **0 Containment** | each static part ≤ R 19.9; each moving part ≤ R 19.5; slider + knob swept **at every 6° of the sweep**, not just the endpoints; SG90 keepout envelope inside R 19.5 |
| **2 Mass / envelope** | per‑part volume, mass (ρ 1.05), bounding radius and Z span |
| **3 Watertight** | mesh vs CAD volume error < 0.3 %, zero open edges, `isSolid`, no non‑manifolds |
| **4 Spring / guide / assembly** | free coils clear of disc + cage + piston; ⌀6 shaft < assumed spring ID; shaft ≥ 5 mm engaged in the disc bore at 0 and 40 mm stroke; **nothing on the shaft below Z −8 fouls the ⌀6.8 bore** (slide‑on); **leg pegs present, disc holes open, locating fit +0.1…+0.4 mm dia** |
| **F FDM fit gaps** | *(new, §6.11)* every moving/removable fit gap computed by **arithmetic on the `CL_*` constants** — slider top & sides, shaft‑in‑bore, knob‑in‑journal, RBF pin, locating peg, disc OD, crank pin, notch/neck — each against its target; reports the thinnest running gap. This is the check a boolean `.common()` **cannot** do (0 mm³ whether the gap is 0.00 or 0.50 mm). |
| **5 The catch** | ARMED — slider rim bearing area on the **CatchCollar top face** and its stress; FIRED — the whole **collar footprint** clear of the slider (this replaces the old “travel ≥ notch + shaft” proxy, which measured the wrong body) and the nearest‑material margin; the **reaction plate** solid above the slider; collar bond shear |
| **6 Crank** | crank pin stays inside the slot over 0–180°; ARMED & FIRED are dead centres; friction → knob torque → fingertip force < 15 N; SG90 headroom |
| **5b Load direction** | *(§6.13/6.14)* measures the **free +Z travel before the catch bites** — the check [5] structurally cannot do. Reports which cage member takes the +Z load, the shaft tension under the bounded cocking drop × a dynamic factor, the **socket joint shear**, and the **shaft side‑load‑to‑break at the socket mouth** both ways (axial ~8 N / shaft‑up ~4 N — the last surfaces §10.2). **0.025 mm, PASS.** |
| **T Thin features** | *(new, rev (d))* every wall/rib *inside one part* against `NOZZLE_W` — the class `[F]` can't see (it only checks gaps *between* parts). Catches: the removed collar rib; the collar's D‑flat wall (0.05 mm — **accepted FAIL**, the flat is pinned by the crank sweep, §6.14); the DummyNose relief bands; the disc rim at the peg holes (§10.12); and a boolean check of the PistonHead hub cap between the socket and the tether hole. |
| **P Printed pins** | *(new)* `CRANK_LEN` / `RBF_LEN` / `CRANK_D` in `ejection_poc_test_pins.py`, checked against `PIN_BOT_Z` / `PIN_TOP_Z` / `CRANK_PIN_R` here. The pin geometry lived in **two files** with nothing tying them together — which is how the crank pin ended up 3 mm too short to reach the slider (§10.17). The build script now *imports* that module for the plate, so there is one source of geometry as well as one check. |
| **11 Print plate** | *(new, §10.18)* packs the batchable parts + pins onto the bed, asserts **nothing overlaps** and it fits, reports the **tightest XY gap** against `PLATE_GAP` (overlap is prevented by the packer, so the number that actually matters on a bed is brim room), then **reads its own 3MF back** and verifies object count, build items and triangle indices — a bad index writes a file that opens as an empty plate, silently. |
| **8 RBF** | clip passes freely at ARMED; fouls the knob after 30°; **and the hole is drilled through solid carrier** *(new — §10.16; the old check was vacuous)* |
| **7 Collisions** | piston sweep vs cage and vs the fixed disc; ARMED slider vs shaft; FIRED knob vs cage; knob shaft vs piston shaft; **shaft, collar and CRANK PIN swept against the cage**; **`PistonHead` swept 0–40 vs cage + disc** *(new — the set that would have caught §10.14 and §10.15)* |
| **9 Features present** | window and access slot actually cut; slider notch and crank slot are open; **shaft solid ⌀6 end to end** — spans the *whole* shaft and reports the true minimum diameter (the old check stopped just below the groove, passing by excluding it); collar halves coincide when mirrored (not just equal volume) |
| **10 Export** | STEP → `Models/`, STL → `Print Files/Ejection System/`, print‑oriented STL → `.../Ready to Print/`, batch plate → `.../Print Plate/`, `.FCStd` |

An independent check would ray‑cast the STLs (as `verify_aft_retention.py` does for the
sibling assembly); not yet written for this one.

---

## 8. Assembly sequence

0. **Build the piston.** Solvent‑weld the **Shaft** into the **PistonHead** hub socket
   (acetone; the shaft top seats on the socket blind end, ~10 mm engaged). Cure fully on
   the bench — this keeps the joint off the critical path of a tube already full of
   spring. *(Alternative: thread the bare shaft down through the disc + spring in step 3
   and glue the head on top afterward — do this only if the head won't clear the tube as
   a pre‑welded unit.)*
1. Press the printed ⌀3 crank pin into the **Knob**. Slide the knob shaft up into the
   **Cage** carrier journal from below; grip ends up under the cage.
2. Drop the **Slider** into its channel on the cage ledge (it should sit with a little
   play, not press in), cross‑slot over the crank pin. Turn the knob to **FIRE** so the
   notch is retracted clear of the centre.
3. On the welded **PistonHead + Shaft**, from the stub (thin) end: slide on the
   **spring**, then the **BulkheadDisc** (bore first, spring‑seat facing the piston).
4. Feed head + spring + loose disc down into the cage from the top; stub through the
   ledge hole. **Push the disc onto the 4 leg pegs** (light hand pressure — the peg
   lead‑cones guide it; the screws in step 5 do the holding).
4b. **Fit the CatchCollar.** Through the access slot, clamp the two identical halves
   around the shaft so the collar's top face is flush with the slider's underside
   (⌀9 × 2.0). Solvent‑weld (acetone) them to the shaft **and to each other**, and let it
   cure before cocking — **the bond is the whole load path** (§6.14); there is no groove
   or rib to fall back on.
5. Slide the cartridge into the **TubeStub**. 3× M3 radial screws into the disc edge,
   3× more into the cage ledge.
6. Fit the **DummyNose**.
7. **Cock:** press the piston down ~40 mm against the spring (a dowel through the nose
   helps) **until the collar bottoms on the ledge shelf** — that is a positive stop, you
   will feel it, and it is only 1.0 mm past the armed position. Turn the knob to **ARM**;
   the notch slides over the collar. Release — the collar rises 1.0 mm onto the slider. Drop the RBF pin through knob + carrier. First fires: tie a
   ~15 mm string from the hub cross‑hole to a cage leg.
8. **Fire:** pull the RBF pin, turn the knob to **FIRE**. Re‑cock from step 7.

---

## 9. How to prove it

1. `FreeCADCmd PhoenixABS40-43_ejection_poc_v1.py` → report all‑PASS.
2. `PhoenixABS40-43_ejection_poc_test_pins.py` → `TestPins_v1.stl`.
3. In FreeCAD: open the assembly `.FCStd`, run `ejection_poc_interactive.py` → a slider
   window; drag ARM ↔ FIRE and watch the crank swing the slider off the collar, then
   the piston jump 40 mm.
4. Print. Two jobs:
   * **`Ejection System/Print Plate/…_ejection_poc_plate_v1.{3mf,stl}`** — the batch:
     `Cage`, `BulkheadDisc`, `DummyNose`, **`PistonHead`**, `Knob`, `Slider`,
     **`CatchCollarHalf` × 2** and the pins, arranged on a 220 × 220 bed (~200 × 80 mm
     used, 12 mm between parts so every one can take a brim — the 62 mm `Cage` will want
     one). `PistonHead` prints disc‑down; give its ⌀11.5 spring pocket a bridge or a
     little support. **Print the collar halves in the orientation the file gives them:**
     lying flat, 2.0 mm tall, curved face up, **split face vertical** — those faces are
     the glue joint and the load path (§6.14); standing one on its split face puts
     elephant's foot on the mating surface.
   * **`Ready to Print/PhoenixABS40-43_{TubeStub,Shaft}_v1.stl`** — printed **alone**:
     `TubeStub` 169 mm vertical, `Shaft` ~117 mm laid **axial** (layers along its
     length). Kept off the plate. Sand the shaft round after printing, or use a ⌀6 CF
     rod (§10.2).
   Dry‑fit per §8.
5. Cock and fire by hand, RBF fitted, tethered. Cock repeatedly — it must re‑arm
   cleanly every time.
6. **Measure `F_max` as a by‑product:** with a luggage/fish scale hooked to the piston,
   read the force to hold it at the 45 mm cocked height. Put that number into
   `F_MAX_ASSUMED` and re‑run the script.

---

## 10. Known limits & open items

| # | Item |
|---|---|
| 1 | **`F_max` unmeasured.** `F_MAX_ASSUMED = 34 N` (mid‑range). Pin shear, rim bearing and ledge are fine across the whole 7–53 N range; the only range‑sensitive number is knob effort, which stays trivial at the top. Measure it (§9.6) and re‑run. |
| 2 | **~105 mm ⌀6 shaft — still the weak part (finding 4).** Split off the head and printed **axially** (§6.15), side‑load to break at the socket mouth is **~8 N** (in‑plane) vs ~4 N shaft‑up — ×2, **not** robust. Report **[5b]** prints the number every run. For a genuinely unbreakable shaft, drop a **⌀6 pultruded CF rod** into the *same* PistonHead socket: ~284 N, no other change, joint shear ~0.2 MPa. A bought part, against brief item 4 — hence still an open item, not the default. |
| 3 | **180° knob sweep** is at the edge of a typical 9 g servo's range. Manual knob is fine. For the servo add a 2:1 crank arm (`CRANK_R` / linkage) or accept a servo that does a clean 180°. |
| 4 | **Catch bears on ABS.** 2.9 MPa on the collar‑top / notch‑rim contact — no strength concern, but watch wear over many cock/fire cycles. The flight bulkhead wants a brass or steel wear insert at the collar top and in the ledge. |
| 5 | **Soft stroke stop.** The spring's free length limits travel gently; there is no positive stop. Fine for bench work with a tether; the flight article needs a positive stop that survives repeated impact. |
| 6 | **Servo not integrated.** v1 = manual knob. v2 = the SG90 on the knob's D‑flat + a proper cradle; the keepout is already checked. |
| 7 | **Disc retention is temporary.** Locating pegs + 3 screws. A flight bulkhead is solvent‑welded or mechanically captured against the full spring + recovery‑shock load. |
| 8 | **No recovery anchor.** Eyelet dropped (§6.10) — put it back for flight. |
| 9 | **Not simulated, not flight‑cleared.** Bench POC only. |
| 10 | **No real "click".** The disc/peg fit is a locating clearance fit (§6.4), not a snap — it does not detent or announce that it seated. If a positive click is wanted before the screws go in, that's a barbed‑peg or cantilever‑finger redesign of the leg tops + disc holes. |
| 11 | **`CL_*` values are first‑principles, not measured on this printer.** `CL_SLIDE 0.5 / CL_ROT 0.4 / CL_BORE 0.4 / CL_PIN 0.25 / CL_PEG 0.2 dia / CL_TUBE 0.25` (§6.11). Print the dry‑fit set, feel the fits, adjust one block, re‑run. Report [F] names the thinnest gap so you know which face to sand if something still binds. |
| 12 | **Thin disc rim at the peg holes.** The ⌀3.2 peg holes sit on a ⌀35.2 circle in a ⌀39.5 disc → 0.55 mm of wall to the OD (was 0.8 mm at ⌀39.7 / ⌀2.9). Fine for a locating pocket (no load — screws carry it), but if a hole splits on assembly, pull `LEG_RC` in ~0.5 mm and re‑run (it also buys leg‑to‑bore clearance). This is why `CL_TUBE` was held to 0.25, not 0.4. |
| 18 | ✅ **Fixed 2026‑09‑06 (c): the plate bundle is generated, not hand‑made.** `Assembled Ready to PRINT/plate_v1.{3mf,stl}` was assembled by hand in a slicer on 2026‑09‑02 and then went stale through **three** revisions — by the end it held a `Cage` whose lip ran straight through the shaft, and §9.4 pointed people at it. It is now built by report **[11]** from the same oriented solids that feed `Ready to Print/`, so it cannot drift again. The old 3MF turned out to be a plain FreeCAD export with no slicer configuration in it, so nothing was lost by regenerating it. `BED_X`/`BED_Y` (220 × 220) are an **assumption** — set them to your printer. |
| 15 | ✅ **Fixed 2026‑09‑06 (c): the crank pin cut into the cage.** The ⌀3 pin sits at `CRANK_R` 3, so it sweeps a disc of **r 4.5** about the knob axis — outside the ⌀7.6 knob shaft, and outside the `JOURNAL_R` 4.2 holes in the ledge *and* the carrier. It was cutting up to 4.9 mm³ out of the ledge and 2.2 mm³ out of the carrier: the knob could not turn. Never caught, because **the pin has never been a modelled solid** — it lives in `ejection_poc_test_pins.py` and no check ever swept it. It is a solid now, swept against cage, collar and shaft every run. Both holes open to 4.9; the knob's lateral bearing moves to a ⌀5.5 **spigot** below the carrier, clear of the pin and on a longer moment arm. |
| 16 | ✅ **Fixed 2026‑09‑06 (c): the RBF pin locked the knob to NOTHING.** `RBF_KR` was +6.0, putting the hole at r 2.0 from the tube axis — **inside** the carrier's `BH_BORE_R + 1` = 4.4 central bore. The pin passed through the knob and then through thin air. That is precisely the brownout case brief requirement 3 exists for. `RBF_KR` is now −7.0 (r 15.0, solid carrier). The check that missed it was vacuous in the classic way — it measured the pin against the cage, which reads ~0 whether the hole is in solid material or in mid‑air; it now measures the **wall around** the hole (82 of 94 mm³). |
| 17 | ✅ **Fixed 2026‑09‑06 (c): the crank pin was 3 mm too short to reach the slider.** Seated in its old −71 bore a 12 mm pin topped out at Z −59, and the slider starts at −56 — it never engaged at all. Bore now starts at −69 (4 mm of glued engagement in the solid knob body) and `CRANK_LEN` is 16.5, giving 3.5 mm of engagement in the 4 mm slider. Checked by `CRANK PIN engages the slider slot`, and report **[P]** now ties the two files together so the next edit cannot drift silently. |
| 13 | ✅ **FIXED 2026‑09‑06 (c) by Option B (§6.14).** ~~Was:~~ ⚠ **The catch was INVERTED.** The spring drives the shaft **+Z** (disc fixed at Z −8…0, piston at Z 45, spring between them). The catch reacts **−Z**: `SHOULDER_Z = −52` is a *downward*‑facing annulus, the slider spans −56…−52, and the ledge is *below* it at −60…−56 — `build_cage` says so ("the slider hooks the shaft shoulder DOWN against this"), and report [5]'s bearing figure is computed on that face. A downward‑facing shoulder cannot restrain an upward‑moving shaft: contact is lost the instant it lifts. What actually catches it is the *upward*‑facing annulus at Z −58 hitting the slider's underside after **2 mm of free travel**, reacting through the printed `lip` — a 2 mm bridged overhang — instead of the ledge. That puts the full ~34 N in **tension through the groove neck** plus a 2 mm impact on every cock‑and‑release. §6.12 doubles the neck's tension area, which mitigates but does not fix it. **The fix is a cage change:** the slider's underside should bear on the groove's upward‑facing shoulder, reacted by a solid full‑diameter plate **above** the slider (the knob has to stay below, so the existing ledge keeps its job as shelf and journal host), and the groove height should drop to slider thickness + ~0.5 mm. §6.13 shows that reversing the reaction face is **necessary but not sufficient** — any groove‑and‑fork catch resisting +Z pulls the neck in tension by construction — and costs the two real options. Confirmed by test 2026‑09‑06: the shaft snapped during cocking. |
| 14 | ✅ **Fixed 2026‑09‑06 (b) — this is what actually broke the shaft.** The user reports it snapped **while being cocked**, which is exactly this: the lip is solid across the shaft’s path, so the shaft cannot reach the cocked position, and forcing it loads the neck’s upper root sideways. The slider‑retaining `lip` (x −17…−1, z −51.5…−49.5) intersected the ⌀6 shaft by 16.5 mm³ over a 2 mm band at the cocked position — a hard collision that made the assembly impossible. Pre‑existing in v1; the report's [7] never tested shaft‑vs‑cage, only *piston disc* sweep vs cage. A ⌀6.8 clearance bore is now cut through the lip (361 mm³ of lip still spans the channel, so it still retains the slider). **Add `shaft vs cage` and a full‑stroke shaft sweep to [7]** when back‑porting. |
| 19 | **No latch detent.** §3.5 / §6.6 say "a detent and the RBF pin cover vibration" — but **no detent is modelled or built**. Between ARM and FIRE the slider is held only by friction (~6.8 N to move it). At the endpoints the crank dead centre holds it, and at ARMED the RBF pin locks the knob. A printed cantilever bump on the knob rim into a carrier notch would add a real detent — deferred on the §6.4 precedent (don't size a snap before the mechanism's real friction has been felt on a print). Fit the RBF pin whenever the article is armed and unattended. |
| 20 | **Collar prints as a C, not a D.** The D‑flat sits 0.05 mm outside the ⌀6.1 bore, so the −X wall is sub‑nozzle and the collar bore opens on that side ([T] flags it, **accepted FAIL**). The flat can't move — it's pinned at exactly `CL_ROT` off the crank‑pin sweep — and the bore can't shrink. Bearing is unaffected (that side is inside the notch); bond area is ~15 % below a full ring, which report [5] now computes directly (~0.98 MPa, still ~10× margin). If the knob layout is ever reworked (`KNOB_AX_X`, `CRANK_R`), this frees up. |
| 21 | **PistonHead↔Shaft is a field glue joint.** New single assembly step (§8.0): a bad or uncured weld is a catch‑load and handling‑load failure. Cure fully before cocking. The joint shear margin is huge (~50×); the risk is workmanship, not stress. |
| 22 | ✅ **Fixed 2026‑09‑08 (d): stale script comments + hard‑coded paths.** The `.py` header, `build_cage` and a `COLLAR_Z0` comment still described the pre‑collar `[5b]`‑fails design; the export paths pointed at the flat `Print Files/` + `Assembled Ready to PRINT/`. All corrected; ejection outputs now write to `Print Files/Ejection System/…` and `.../Print Plate/`. The **aft‑retention** scripts still use the flat layout — that half of the `Print Files/README.md` warning stays live. |

---

## 11. Files

```
Models/
  PhoenixABS40-43_ejection_poc_v1.py          parametric source of truth — edit here, re-run
  ejection_poc_test_pins.py                     -> Print Files/Ejection System/..._TestPins_v1.stl
  ejection_poc_interactive.py                   FreeCAD macro: ARM/FIRE slider on the open assembly
  ejection_poc_build_report_v1.txt              every check, every run -- see §7 for the deliberate flags
  EJECTION_POC_DESIGN.md                        this document
  PhoenixABS40-43_ejection_poc_v1.FCStd         assembly — 9 solids in position
  PhoenixABS40-43_{Cage,BulkheadDisc,PistonHead,Shaft,Slider,Knob,TubeStub,DummyNose,CatchCollar,CatchCollarHalf}_v1.step
Print Files/Ejection System/
  PhoenixABS40-43_{9 parts}_v1.stl             model frame (un-oriented)
  PhoenixABS40-43_TestPins_v1.stl              3 crank + 2 RBF pins
  Ready to Print/PhoenixABS40-43_{parts}_v1.stl   pre-oriented, dropped to Z = 0
      Shaft   -> laid AXIAL (layers along the length, §6.15) -- the default now; no _FLAT variant
      PistonHead -> disc down; bridge/support the d11.5 spring pocket
  Ready to Print/PhoenixABS40-43_CatchCollarHalf_v1.stl    PRINT THIS x2 -- the two halves are identical (6.14)
  PhoenixABS40-43_PistonShaftOnePiece_v1.stl   +  Ready to Print/ (disc down, shaft up)
      one-piece head+shaft, NO socket -- bench comparison for the split pair (§6.15, [C]).
      ~4 N shaft-up vs ~8 N for the split. NOT recommended, NOT on the plate.
  (no Ready-to-Print STL for the one-piece CatchCollar: a d9 ring cannot go onto a shaft
   that must thread the d6.8 bulkhead bore. Models/ keeps it as an assembly reference only.)
  Print Plate/PhoenixABS40-43_ejection_poc_plate_v1.{3mf,stl}   GENERATED by the script
      (report [11]): the batchable parts (incl. PistonHead) + CatchCollarHalf x2 + pins,
      packed and collision-checked. TubeStub and Shaft are NOT on it -- print those alone.
```

Print orientation is baked into the `Ready to Print/` and plate files. Notable:
`Shaft` — laid axial, layers along the length (sand round, or use a CF rod, §10.2);
`PistonHead` — disc down, bridge the spring pocket; `Cage` — carrier end down, legs up,
light support under the ledge; `Slider`/`Knob`/`BulkheadDisc`/pins — flat, no support;
`TubeStub` — vertical, brim. `TubeStub` (169 mm) and `Shaft` (~117 mm) print alone.

---

## 12. The parameters worth turning

All in the constants block of the `.py`.

| Constant | Effect |
|---|---|
| `CL_SLIDE / CL_ROT / CL_BORE / CL_PIN / CL_PEG / CL_TUBE / CL_CLAMP` (0.5 / 0.4 / 0.4 / 0.25 / 0.2 / 0.25 / 0.1) | **the FDM fit block** — every moving/removable interface derives from these; `CL_CLAMP` is the collar bore *and* the shaft socket (a weld, not a running fit); tune to your printer, re‑run, read report [F] (§6.11) |
| `NOZZLE_W` (0.4) | extrusion width — report **[T]** fails any wall/rib thinner than this, warns under 2× |
| `SIGMA_ABS_INPLANE / SIGMA_ABS_INTERLAYER` (40 / 20) | ABS bending stress along vs across layers; [5b] reports shaft side‑load‑to‑break both ways |
| `STROKE` (40) | drives the **entire vertical stack** — one edit gives the full‑stroke flight geometry |
| `F_MAX_ASSUMED` (34), `MU` (0.2) | not geometry — they set the reported forces/margins; update after measuring |
| `SLIDER_TRAVEL` (6) → `CRANK_R` | how far the slider clears the collar; ≥ `NOTCH_R + SHAFT_R` |
| `SHAFT_R` (3), `SPRING_ID_MIN` (7.2) | shaft must stay below the real spring ID once measured; the socket mouth chamfer peak also checks against this ([F]) |
| `SHAFT_JOINT_DEPTH` (10), `SOCKET_CHAMFER` (0.3) | the PistonHead↔Shaft socket (§6.15). Depth sets glue area + the hub cap over it ([T]); chamfer peak must clear `SPRING_ID_MIN` |
| `KNOB_AX_X` (−8), `KNOB_R` (10) | knob offset + size; keep `|KNOB_AX_X| + KNOB_R + scallop < 19.5` |
| `LEG_PEG_R` (1.5), `CL_PEG` (0.2 dia) | the locating‑peg fit; `DISC_PEG_HOLE_R` derives as `LEG_PEG_R + CL_PEG/2` |
| `NOTCH_R` (3.4) | clears the solid ⌀6 shaft (`SHAFT_R + CL_BORE`); the rim bears on the collar |
| `COLLAR_R` (4.5), `COLLAR_H` (2.0), `COLLAR_FLAT_X` (−3.1) | the catch (§6.14). Radius capped by FIRED slider clearance; the flat pinned at `CL_ROT` off the crank‑pin sweep (so the collar prints as a C — §10.20); the height by `COLLAR_COCK_GAP` |
| `COLLAR_COCK_GAP` (1.0) | the positive cocking stop — **this is the entire free rise**. It must stay above the unloaded slider droop (0.62 mm, reported by [5]) or the slider fouls the collar while arming; the [5b] impact number scales with it |
| `R_MAX_MOVING` (19.5), `R_MAX_STATIC` (19.9) | the containment limits everything is checked against |
